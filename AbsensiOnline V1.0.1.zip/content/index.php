<?php
// Email: mycoding@401xd.com / 401xdssh@gmail.com
//
// ▪ http://401xd.com / http://mycoding.id
// ▪ http://youtube.com/c/MyCodingXD
// ▪ http://instagram.com/MyCodingXD
// ▪ http://facebook.com/MyCodingXD
//
// Hak cipta 2017-2021
// Terakhir dikembangkan Juli 2021

header("location: /");
?>